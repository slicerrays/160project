/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cipherapp;

/**
 *
 * @author rios6
 */
public class CipherApp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
